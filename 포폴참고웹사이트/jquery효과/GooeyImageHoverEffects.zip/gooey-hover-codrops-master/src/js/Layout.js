
export default class Layout {

    constructor() {
        this.isMobile  = window.matchMedia('(max-width: 767px)').matches
    }

}
